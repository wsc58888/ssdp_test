--查询所有发起的流程，根据act_ru_task判断当前流程是否在执行中
--根据act_ru_identitylink判断当前流程的处理人是谁
--act_ru_task.form_key_获取任务节点页面
--act_re_procdef.category_  获取流程查看页面

select t1.business_key_,t1.proc_inst_id_,t1.start_time_,t1.start_user_id_,
       t2.id_,t2.name_,t2.task_def_key_,t2.create_time_ ,t2.form_key_,
       t3.user_id_,
       t4.category_,t4.key_

from act_hi_procinst t1
left join act_ru_task t2
on t1.proc_inst_id_=t2.proc_inst_id_
left join act_ru_identitylink t3
          on t2.id_=t3.task_id_ and t3.type_='candidate'
left join act_re_procdef t4
          on t1.proc_def_id_=t4.id_
