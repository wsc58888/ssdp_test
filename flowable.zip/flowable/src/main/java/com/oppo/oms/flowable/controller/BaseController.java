package com.oppo.oms.flowable.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.github.pagehelper.StringUtil;

@Controller
public class BaseController {
	
	@Value("${spring.application.name:}")
	private String appName;
	@Value("${spring.application.title:}")
	private String appTitle;
	
	@ModelAttribute
    public void init(Model model)
    {
		model.addAttribute("appName", "");
		model.addAttribute("appTitle", getWebTitle());
    }
	
	public String getPath() {
		if(!StringUtil.isEmpty(appName)) {
			return "/" + appName;
		}
		return "";
	}

	public String getWebTitle() {
		if(!StringUtil.isEmpty(appTitle)) {
			return  appTitle;
		}
		return "Oppo";
	}

	 
}