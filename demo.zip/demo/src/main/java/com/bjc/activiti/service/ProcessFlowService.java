package com.bjc.activiti.service;

import java.util.Map;

public interface ProcessFlowService {

    void Start(String processKey, String businessId, Map<String, Object> map);


    void process(String taskId, Map<String, Object> map);


    void delete(String taskId);

    void transfer(String taskId, String user);
}
