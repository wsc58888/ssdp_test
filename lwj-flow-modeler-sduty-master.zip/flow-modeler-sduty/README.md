# flow-modeler-study

#### 介绍
flowable modeler集成demo

#### 软件架构
软件架构说明


#### 安装教程

1. 本地创建一个数据库叫flow-study
2. 修改数据库的账号密码
3. 访问登录界面
http://127.0.0.1:8989/flow-study/idm/index.html
4. 访问流程设计器 
http://127.0.0.1:8989/flow-study/

#### 自我介绍

1. 本人热爱技术，希望和志同道合的同仁一起探讨技术
2. 建了一个qq群： 633168411 如果不懂可以加群，请备注学习flowable，否则不予通过
4. 我博客的flowable地址 https://www.cnblogs.com/liuwenjun/category/1296599.html