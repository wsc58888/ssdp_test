package com.oppo.oms.flowable.controller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.batik.transcoder.TranscoderInput;
import org.apache.batik.transcoder.TranscoderOutput;
import org.apache.batik.transcoder.image.PNGTranscoder;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.flowable.bpmn.converter.BpmnXMLConverter;
import org.flowable.bpmn.model.BpmnModel;
import org.flowable.common.engine.api.FlowableException;
import org.flowable.editor.constants.ModelDataJsonConstants;
import org.flowable.editor.language.json.converter.BpmnJsonConverter;
import org.flowable.engine.RepositoryService;
import org.flowable.engine.repository.Deployment;
import org.flowable.engine.repository.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.oppo.oms.flowable.common.PageUtils;
import com.oppo.oms.flowable.common.Result;

@RestController
@RequestMapping("/flowabel")
public class ModelController extends BaseController{
	 protected static final Logger LOGGER = LoggerFactory.getLogger(ModelController.class);

	    @Autowired
	    private RepositoryService repositoryService;

	    @Autowired
	    private ObjectMapper objectMapper;

	  
	    @GetMapping("/model")
	    ModelAndView model() {
	        return new ModelAndView("activiti/model/model");
	    }

	    @GetMapping("/model/list")
	    PageUtils list(String name,int offset, int limit) {
	        List<Model> list = repositoryService.createModelQuery().modelNameLike("%"+(name==null?"":name)+"%").listPage(offset
	                , limit);
	        int total = (int) repositoryService.createModelQuery().modelNameLike("%"+(name==null?"":name)+"%").count();
	        PageUtils pageUtil = new PageUtils(list, total);
	        return pageUtil;
	    }

	    @RequestMapping("/model/add")
	    public void newModel(HttpServletResponse response) throws UnsupportedEncodingException {

	        //初始化一个空模型
	        Model model = repositoryService.newModel();
	        //设置一些默认信息
	        String name = "new-process";
	        String description = "";
	        int revision = 1;
	        String key = "process";

	        ObjectNode modelNode = objectMapper.createObjectNode();
	        modelNode.put(ModelDataJsonConstants.MODEL_NAME, name);
	        modelNode.put(ModelDataJsonConstants.MODEL_DESCRIPTION, description);
	        modelNode.put(ModelDataJsonConstants.MODEL_REVISION, revision);

	        model.setName(name);
	        model.setKey(key);
	        model.setMetaInfo(modelNode.toString());

	        repositoryService.saveModel(model);
	        String id = model.getId();

	        //完善ModelEditorSource
	        ObjectNode editorNode = objectMapper.createObjectNode();
	        editorNode.put("id", "canvas");
	        editorNode.put("resourceId", "canvas");
	        ObjectNode stencilSetNode = objectMapper.createObjectNode();
	        stencilSetNode.put("namespace",
	                "http://b3mn.org/stencilset/bpmn2.0#");
	        editorNode.put("stencilset", stencilSetNode);
	        repositoryService.addModelEditorSource(id, editorNode.toString().getBytes("utf-8"));
	        try {
	            response.sendRedirect(getPath()+"/modeler?modelId=" + id);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    @GetMapping(value = "/model/{modelId}/json")
	    public JSONObject getEditorJson(@PathVariable String modelId) {
	        JSONObject modelNode = null;
	        Model model = repositoryService.getModel(modelId);
	        if (model != null) {
	            try {
	                if (StringUtils.isNotEmpty(model.getMetaInfo())) {
	                    //modelNode = (ObjectNode) objectMapper.readTree(model.getMetaInfo());
	                    modelNode=JSONObject.parseObject(model.getMetaInfo());
	                } else {
	                    //modelNode = objectMapper.createObjectNode();
	                    modelNode.put(ModelDataJsonConstants.MODEL_NAME,model.getName());
	                    //modelNode.put(, );
	                }

	                modelNode.put(ModelDataJsonConstants.MODEL_ID, model.getId());
	                JSONObject editorJsonNode = JSONObject.parseObject(
	                        new String(repositoryService.getModelEditorSource(model.getId()), "utf-8"));
	                modelNode.put("model", editorJsonNode);

	            } catch (Exception e) {
	                LOGGER.error("Error creating model JSON", e);
	                throw new FlowableException("Error creating model JSON", e);
	            }
	        }
	        return modelNode;
	    }

	    @RequestMapping(value = "/editor/stencilset", method = RequestMethod.GET, produces = "application/json;charset=utf-8")
	    public JSONObject getStencilset() {
	        InputStream stencilsetStream = this.getClass().getClassLoader().getResourceAsStream("stencilset.json");
	        try {

	            return JSON.parseObject(IOUtils.toString(stencilsetStream, "utf-8"));
	        } catch (Exception e) {
	            throw new FlowableException("Error while loading stencil set", e);
	        }
	    }

	    @GetMapping("/model/edit/{id}")
	    public void edit(HttpServletResponse response, @PathVariable("id") String id) {
	        try {
	            response.sendRedirect(getPath()+"/modeler?modelId=" + id);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    @DeleteMapping("/model/{id}")
	    public Result remove(@PathVariable("id") String id) {
	        repositoryService.deleteModel(id);
	        return Result.ok();
	    }

	    @PostMapping("/model/deploy/{id}")
	    public Result deploy(@PathVariable("id") String id) throws Exception {
	        //获取模型
	        Model modelData = repositoryService.getModel(id);
	        byte[] bytes = repositoryService.getModelEditorSource(modelData.getId());

	        if (bytes == null) {
	            return Result.error("模型数据为空，请先设计流程并成功保存，再进行发布。");
	        }

	        JsonNode modelNode = new ObjectMapper().readTree(bytes);

	        BpmnModel model = new BpmnJsonConverter().convertToBpmnModel(modelNode);
	        if (model.getProcesses().size() == 0) {
	            return Result.error("数据模型不符要求，请至少设计一条主线流程。");
	        }
	        byte[] bpmnBytes = new BpmnXMLConverter().convertToXML(model);

	        //发布流程
	        String processName = modelData.getName() + ".bpmn20.xml";
	        Deployment deployment = repositoryService.createDeployment()
	                .name(modelData.getName())
	                .addString(processName, new String(bpmnBytes, "UTF-8"))
	                .deploy();
	        modelData.setDeploymentId(deployment.getId());
	        repositoryService.saveModel(modelData);

	        return Result.ok();
	    }

	    @PostMapping("/model/batchRemove")
	    public Result batchRemove(@RequestParam("ids[]") String[] ids) {
	        for (String id : ids) {
	            repositoryService.deleteModel(id);
	        }
	        return Result.ok();
	    }

	    @RequestMapping(value = "/model/{modelId}/save", method = RequestMethod.PUT)
	    @ResponseStatus(value = HttpStatus.OK)
	    public void saveModel(@PathVariable String modelId
	            , String name, String description
	            , String json_xml, String svg_xml) {
	        try {

	            Model model = repositoryService.getModel(modelId);

	            ObjectNode modelJson = (ObjectNode) objectMapper.readTree(model.getMetaInfo());

	            modelJson.put(ModelDataJsonConstants.MODEL_NAME, name);
	            modelJson.put(ModelDataJsonConstants.MODEL_DESCRIPTION, description);
	            model.setMetaInfo(modelJson.toString());
	            model.setName(name);

	            repositoryService.saveModel(model);

	            repositoryService.addModelEditorSource(model.getId(), json_xml.getBytes("utf-8"));

	            InputStream svgStream = new ByteArrayInputStream(svg_xml.getBytes("utf-8"));
	            TranscoderInput input = new TranscoderInput(svgStream);

	            PNGTranscoder transcoder = new PNGTranscoder();
	            // Setup output
	            ByteArrayOutputStream outStream = new ByteArrayOutputStream();
	            TranscoderOutput output = new TranscoderOutput(outStream);

	            // Do the transformation
	            transcoder.transcode(input, output);
	            final byte[] result = outStream.toByteArray();
	            repositoryService.addModelEditorSourceExtra(model.getId(), result);
	            outStream.close();

	        } catch (Exception e) {
	            LOGGER.error("Error saving model", e);
	            throw new FlowableException("Error saving model", e);
	        }
	    }

	    @GetMapping("/model/export/{id}")
	    public void exportToXml(@PathVariable("id") String id, HttpServletResponse response) {
	        try {
	            org.flowable.engine.repository.Model modelData = repositoryService.getModel(id);
	            BpmnJsonConverter jsonConverter = new BpmnJsonConverter();
	            JsonNode editorNode = new ObjectMapper().readTree(repositoryService.getModelEditorSource(modelData.getId()));
	            BpmnModel bpmnModel = jsonConverter.convertToBpmnModel(editorNode);
	            BpmnXMLConverter xmlConverter = new BpmnXMLConverter();
	            byte[] bpmnBytes = xmlConverter.convertToXML(bpmnModel);

	            ByteArrayInputStream in = new ByteArrayInputStream(bpmnBytes);
	            IOUtils.copy(in, response.getOutputStream());
	            String filename = bpmnModel.getMainProcess().getId() + ".bpmn20.xml";
	            response.setHeader("Content-Disposition", "attachment; filename=" + filename);
	            response.flushBuffer();
	        } catch (Exception e) {
	            throw new FlowableException("导出model的xml文件失败，模型ID=" + id, e);
	        }
	    }
}
