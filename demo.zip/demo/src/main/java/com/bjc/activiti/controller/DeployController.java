package com.bjc.activiti.controller;

import org.activiti.engine.ActivitiException;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.ProcessDefinition;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipInputStream;

@Controller
@RequestMapping({"/bjc-activiti/process/deploy"})
public class DeployController {
    @Autowired
    private ProcessEngine processEngine;
    @RequestMapping({"/save"})
    @ResponseBody
    @Transactional(
            readOnly = false
    )
    public Map<String, String> deploy( MultipartFile file) {
        //流程部署 将绘制的流程图文件进行部署



        Map<String, String> map = new HashMap<>();
        String message = "";
        String fileName = file.getOriginalFilename();

        try {
            InputStream fileInputStream = file.getInputStream();
            Deployment deployment = null;
            String extension = FilenameUtils.getExtension(fileName);
            if (!extension.equals("zip") && !extension.equals("bar")) {
                if (extension.equals("png")) {
                    deployment = this.processEngine.getRepositoryService().createDeployment().addInputStream(fileName, fileInputStream).deploy();
                } else if (fileName.indexOf("bpmn20.xml") != -1) {
                    deployment = this.processEngine.getRepositoryService().createDeployment().addInputStream(fileName, fileInputStream).deploy();
                } else if (extension.equals("bpmn")) {
                    String baseName = FilenameUtils.getBaseName(fileName);
                    deployment = this.processEngine.getRepositoryService().createDeployment().addInputStream(baseName + ".bpmn20.xml", fileInputStream).deploy();
                } else {
                    message = "不支持的文件类型：" + extension;
                }
            } else {
                ZipInputStream zip = new ZipInputStream(fileInputStream);
                deployment = this.processEngine.getRepositoryService().createDeployment().addZipInputStream(zip).deploy();
            }

            List<ProcessDefinition> list = this.processEngine.getRepositoryService().createProcessDefinitionQuery().deploymentId(deployment.getId()).list();
            Iterator var11 = list.iterator();

            while (var11.hasNext()) {
                ProcessDefinition processDefinition = (ProcessDefinition) var11.next();
                this.processEngine.getRepositoryService().setProcessDefinitionCategory(processDefinition.getId(), processDefinition.getCategory());
                message = message + "部署成功，流程ID=" + processDefinition.getId() + "<br/>";
            }

            if (list.size() == 0) {
                map.put("code", "500");
                message = "部署失败，没有流程。";
            }
            map.put("code", "200");
        } catch (Exception var14) {
            map.put("code", "500");
            throw new ActivitiException("部署失败！", var14);
        }
        map.put("msg", message);
        return map;
    }

    @GetMapping
    public String addPage(){
        return "activiti/deploy/add";
    }
}
