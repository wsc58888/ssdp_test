package com.bjc.demo.controller;

import com.bjc.activiti.service.ProcessFlowService;
import org.activiti.engine.ActivitiException;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.ProcessDefinition;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.*;
import java.util.zip.ZipInputStream;

@Controller
@RequestMapping({"/demo"})
public class DemoController {
    @Autowired
    private ProcessFlowService processFlowService;

    @RequestMapping({"/start"})
    @ResponseBody
    @Transactional(
            readOnly = false
    )
    public void stawrt() {
        //发起流程   users1 对应第一个节点审批人
        Map<String,Object> map=new HashMap<>();
        List<String> list=new ArrayList<>();
        list.add("张三");
        list.add("李四");
        map.put("users1",list);
        map.put("users2",list);
        processFlowService.Start("employeeLeave",new Date().getTime()+"",map);

    }


    @RequestMapping({"/process"})
    @ResponseBody
    @Transactional(
            readOnly = false
    )
    public void process() {
        //发起流程   users1 对应第一个节点审批人
        Map<String,Object> map=new HashMap<>();
        map.put("status1","2");
        processFlowService.process("5010",map);

    }


    @GetMapping
    public String addPage(){
        return "activiti/deploy/add";
    }
}
