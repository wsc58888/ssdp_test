package com.bjc.activiti.service.impl;

import com.bjc.activiti.service.ProcessFlowService;
import org.activiti.engine.ProcessEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class ProcessFlowServiceImpl implements ProcessFlowService {
    @Autowired
    private ProcessEngine processEngine;
    @Override
    public void Start(String processKey, String businessId, Map<String, Object> map) {
        //发起流程
        //需要流程 ID, 当前操作人，业务ID，流程参数

        this.processEngine.getIdentityService().setAuthenticatedUserId("张三");

        processEngine.getRuntimeService().startProcessInstanceByKey(processKey,businessId,map);
        this.processEngine.getIdentityService().setAuthenticatedUserId(null);
    }

    @Override
    public void process(String taskId, Map<String, Object> map) {
        //处理流程
        //需要任务ID, 当前操作人，流程参数
        this.processEngine.getIdentityService().setAuthenticatedUserId("张三");
        processEngine.getTaskService().complete(taskId,map);

        this.processEngine.getIdentityService().setAuthenticatedUserId(null);
    }
    @Override
    public void delete(String processInstance){

        //删除流程
        //根据任务ID删除
        processEngine.getRuntimeService().deleteProcessInstance(processInstance,"");
    }

    @Override
    public void transfer(String taskId, String user){

        //转审，任务ID与用户ID
        processEngine .getTaskService().setAssignee(taskId, user);
      //  processEngine.getTaskService().addCandidateUser(String,user);
    }


}
